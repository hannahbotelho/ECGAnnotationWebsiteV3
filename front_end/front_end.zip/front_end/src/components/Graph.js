import React, {Component} from 'react';
import {Scatter} from 'react-chartjs-2';
import * as d3 from 'd3';

// Set constant colors here
let lightOpacity = .2
let colorP = 'rgb(217, 128, 250)';
let colorPOpacity = 'rgb(217, 128, 250,' + lightOpacity + ')';
let colorQ = 'rgb(247, 159, 31)';
let colorQOpacity = 'rgb(247, 159, 31,' + lightOpacity + ')';
let colorR = 'rgb(234, 32, 39)';
let colorROpacity = 'rgb(234, 32, 39,' + lightOpacity + ')';
let colorR2 = 'rgb(237, 76, 103)';
let colorR2Opacity = 'rgb(237, 76, 103,' + lightOpacity + ')';
let colorS = 'rgb(163, 203, 56)';
let colorSOpacity = 'rgb(163, 203, 56,' + lightOpacity + ')';
let colorT = 'rgb(6, 82, 221)';
let colorTOpacity = 'rgb(6, 82, 221,' + lightOpacity + ')';
let colorT2 = 'rgb(18, 137, 167)';
let colorT2Opacity = 'rgb(18, 137, 167,' + lightOpacity + ')';
let colorOn = 'rgb(27, 20, 100)';
let colorOnOpacity = 'rgb(27, 20, 100,' + lightOpacity + ')';
let colorOff = 'rgb(111, 30, 81)';
let colorOffOpacity = 'rgb(111, 30, 81,' + lightOpacity + ')';

// Each logLine will be a single element in this list
// When the save function is activated in this method, it
// will write whats in this variable to an output file
var logLines = [];

var queryResult = [];

/**
 * This component defines the individual graphs for each lead and annotation set
 */
class Graph extends Component {

    /**
     * Constructor is used here to create a ref and set initial state according to the props
     */
    constructor(props) {
        super(props);


        this.chartRef = React.createRef();
        this.componentDidUpdate = this.componentDidUpdate.bind(this);
        this.getLeadID = this.getLeadID.bind(this);
        this.insertIntoDB = this.insertIntoDB.bind(this);
        this.deleteFromDB = this.deleteFromDB.bind(this);
        this.updateDB = this.updateDB.bind(this);




        this.state = ({
            data: {
                datasets: {
                    dataRead: false,
                    radius: 0, // Makes the dots go away
                    label: this.props.inputArr.title,
                    fill: false,
                    borderColor: ['black'],
                    data: this.props.inputArr.data,
                    backgroundColor: ['rgba(255,99,132,0.6)',],
                    borderWidth: 1
                },
                annotation: {
                    p: [{x: 0, y: 10000}], // y's need an initial point, which is outside of range of graph
                    q: [{x: 0, y: 10000}], // however, they are removed on the first update
                    r: [{x: 0, y: 10000}],
                    r2: [{x: 0, y: 10000}],
                    s: [{x: 0, y: 10000}],
                    t: [{x: 0, y: 10000}],
                    t2: [{x: 0, y: 10000}],
                    onset: [{x: 0, y: 10000}],
                    offset: [{x: 0, y: 10000}],
                    selectedAnnotation: -1,
                    oldP: [''],
                    oldQ: [''],
                    oldR: [''],
                    oldR2: [''],
                    oldS: [''],
                    oldT: [''],
                    oldT2: [''],
                    oldOnset: [''],
                    oldOffset: [''],
                    p_flag: false,
                    q_flag: false,
                    r_flag: false,
                    r2_flag: false,
                    s_flag: false,
                    t_flag: false,
                    t2_flag: false,
                    onset_flag: false,
                    offset_flag: false,
                },
                scanID: 0,
                freq: 0,
                max: this.props.inputArr.extra_info.max,
                min: this.props.inputArr.extra_info.min,
                parent_width: 0,
                annos: [],
                shouldUpdate: false,
                events: '',
                p_pair: [], q_pair: [], r_pair: [], s_pair: [], t_pair: []  //temp
            }
        })
    }

    /**
     *
     * @brief This method deletes the annotation from annotationArray at arrayIndex.
     * After deletion the state is updated and chart rerendered
     *
     * @param {[]} annotationArray representing the data array for a given annotation
     * @param {int} arraryIndex representing the index for deletion in the given array
     * @param {Event} event representing the click event returned by chartJS
     */
    deleteAnnotation(annotationArray, arraryIndex, event) {
        //annotationArray[arraryIndex] = ""; // Dont delete, just make it empty
        annotationArray.splice(arraryIndex, 1)
        //console.log(annotationArray);

        event[0]._chart.chart.update();
    }

    /**
     *
     * @brief This method adds an annotation located at the coordinates of the point parameter
     * to the passed in annotationArray. It also causes a rerender and updates state after addition
     *
     * @param {[]} annotationArray representing the data array for a given annotation
     * @param {Event} event representing the click event returned by chartJS
     * @param {Object} point representing the (x,y) coordinates of the click
     */
    addAnnotation(annotationArray, event, point) {
        annotationArray.push({x: point.x, y: point});
        //console.log(annotationArray);

        event[0]._chart.chart.update();
    }

    // This function will save the logFile, is called when the 'save' button is pressed in MainContainer

    insertIntoDB(ecgID, leadID, pointIndex, pointType, annotatorID) {

        if (annotatorID == 1) {

            var url = new URL("http://128.4.30.6:5000/insertFirstAnnotator"),
                params = {ecgID: ecgID, leadID: leadID, pointIndex: pointIndex, pointType: pointType};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url).catch(err => console.log(err));

        } else {
            var url = new URL("http://128.4.30.6:5000/insertSecondAnnotator"),
                params = {ecgID: ecgID, leadID: leadID, pointIndex: pointIndex, pointType: pointType};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url).catch(err => console.log(err));
        }

    }

    deleteFromDB(ecgID, leadID, pointIndex, annotatorID) {

        if (annotatorID == 1) {

            var url = new URL("http://128.4.30.6:5000/deleteFirstAnnotator"),
                params = {ecgID: ecgID, leadID: leadID, pointIndex: pointIndex};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url).catch(err => console.log(err));

        } else {
            var url = new URL("http://128.4.30.6:5000/deleteSecondAnnotator"),
                params = {ecgID: ecgID, leadID: leadID, pointIndex: pointIndex};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]))
            fetch(url).catch(err => console.log(err));
        }

    }

    static handleQueryResults(body) {

        var e = body;
        console.log(body);
        var v = 9;
    }

    static selectFromDB(ecgID, annotatorID) {

        var result = null;

        if (annotatorID == 1) {

            const url = new URL("http://128.4.30.6:5000/getFirstAnnotator"),
                params = {ecgID: ecgID};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

            fetch(url)
                .then(function (response) {
                    return response.json()
                }).then(function (body) {

                body.forEach(item => {

                    console.log('Hi');
                    console.log(item.PointIndex);

                });

            });

        } else {

            const url = new URL("http://128.4.30.6:5000/getSecondAnnotator"),
                params = {ecgID: ecgID};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

            fetch(url)
                .then(function (response) {
                    return response.json()
                }).then(function (body) {
                this.handleQueryResults(body);
            });
        }

        return result;
    }


    static saveFunction(outputName, outputType) {

        this.insertIntoDB(2,0,100,2,1);
        this.insertIntoDB(2,0,200,2,1);
        this.insertIntoDB(2,0,300,2,1);
        this.insertIntoDB(2,0,400,2,1);
        this.insertIntoDB(2,0,500,2,1);
    }

    /**
     *
     * @brief Method that is called whenever a point is clicked on the graph, where e is the click event.
     * This method handles determining whether to add or remove an annotation and calls the required method
     *
     * @param {Event} e which is the click event returned by chartJS
     */

     getLeadID(label) {

        switch (label) {

            case 'I': return 0;
            case 'II': return 1;
            case 'III': return 2;
            case 'aVR': return 3;
            case 'aVL': return 4;
            case 'aVF': return 5;
            case 'V1': return 6;
            case 'V2': return 7;
            case 'V3': return 8;
            case 'V4': return 9;
            case 'V5': return 10;
            case 'V6': return 11;

        }
    }


    updateDB(e) {
        let editMode = e[0]._datasetIndex;
        let annotatorID = this.props.inputArr.annotatorID;

        if ( editMode == 0) { // Insert into DB

            let ecgID = this.state.data.scanID;
            let leadID = this.getLeadID(this.state.data.datasets.label);
            let pointIndex = e[0]._index;
            let pointType = this.state.data.annotation.selectedAnnotation;
            if (typeof pointType !== 'undefined') {
                this.insertIntoDB(ecgID, leadID, pointIndex, pointType, annotatorID);
            }


        } else { // Delete from DB
            let ecgID = this.state.data.scanID;
            let leadID = this.getLeadID(this.state.data.datasets.label);
            let pointIndex = -1;
            let annIndex = e[0]._index;
            let pointType = editMode - 1;
            let ecgFreq = this.state.data.freq;

            switch (pointType) {

                case 0: {
                    let pointObject = this.state.data.annotation.p[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }
                case 1: {
                    let pointObject = this.state.data.annotation.q[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }
                case 2: {
                    let pointObject = this.state.data.annotation.r[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }
                case 3: {
                    let pointObject = this.state.data.annotation.r2[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }
                case 4: {
                    let pointObject = this.state.data.annotation.s[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }
                case 5: {
                    let pointObject = this.state.data.annotation.t[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                }
                case 6: {
                    let pointObject = this.state.data.annotation.t2[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }
                case 7: {
                    let pointObject = this.state.data.annotation.onset[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }
                case 8: {
                    let pointObject = this.state.data.annotation.offset[annIndex];
                    let pointTime = pointObject.x;
                    pointIndex = pointTime * ecgFreq;
                    break;
                }

            }

            this.deleteFromDB(ecgID, leadID, pointIndex, annotatorID);
            console.log(`Deleting point at index ${pointIndex}`);

            var e = 9;
        }
    }

    modifyGraph(e) {

        this.updateDB(e);

        //console.log(e);

        //const node = this.chartRef.current;

        let arrIndex = e[0]._index;
        let dataSet = e[0]._datasetIndex;
        let coordinates = this.state.data.datasets.data[arrIndex];



        //console.log("scanID:", this.state.data.scanID);
        switch (dataSet) {
            case 0:
                //add a point to a specific set of annotations
                //console.log(this.state.data.datasets.data);
                //console.log("Coordinates",coordinates);

                //Let the user select the type of point to add from some menu
                //and set the response to this variable
                //Hardcoded to 0 now to inidicate P
                let inputChoice = this.state.data.annotation.selectedAnnotation;
                if (inputChoice === -1) {
                    break;
                }


                //User wants to add P
                if (inputChoice === 0) {
                    this.addAnnotation(this.state.data.annotation.p, e, coordinates);
                }
                else if (inputChoice === 1) {
                    this.addAnnotation(this.state.data.annotation.q, e, coordinates);
                }
                else if (inputChoice === 2) {
                    this.addAnnotation(this.state.data.annotation.r, e, coordinates);
                }
                else if (inputChoice === 3) {
                    this.addAnnotation(this.state.data.annotation.r2, e, coordinates);
                }
                else if (inputChoice === 4) {
                    this.addAnnotation(this.state.data.annotation.s, e, coordinates);

                }else if (inputChoice === 5) {
                    this.addAnnotation(this.state.data.annotation.t, e, coordinates);

                }else if (inputChoice === 6) {
                    this.addAnnotation(this.state.data.annotation.t2, e, coordinates);

                }else if (inputChoice === 7) {
                    this.addAnnotation(this.state.data.annotation.onset, e, coordinates);

                }else if (inputChoice === 8) {
                    this.addAnnotation(this.state.data.annotation.offset, e, coordinates);
                }
                break;
            case 1:
                this.deleteAnnotation(this.state.data.annotation.p, arrIndex, e);
                break;
            case 2:
                this.deleteAnnotation(this.state.data.annotation.q, arrIndex, e);
                break;
            case 3:
                this.deleteAnnotation(this.state.data.annotation.r, arrIndex, e);
                break;
            case 4:
                this.deleteAnnotation(this.state.data.annotation.r2, arrIndex, e);
                break;
            case 5:
                this.deleteAnnotation(this.state.data.annotation.s, arrIndex, e);
                break;
            case 6:
                this.deleteAnnotation(this.state.data.annotation.t, arrIndex, e);
                break;
            case 7:
                this.deleteAnnotation(this.state.data.annotation.t2, arrIndex, e);
                break;
            case 8:
                this.deleteAnnotation(this.state.data.annotation.onset, arrIndex, e);
                break;
            case 9:
                this.deleteAnnotation(this.state.data.annotation.offset, arrIndex, e);
                break;
            default:
                console.log("Point not in any available dataset.");
        }

        //console.log('Call saveFunction');
        //let testStr = "x"
        logLines.push('x')
        console.log('Update Made', logLines)
    }

    //Function to generalize the loading of annotation files
    //Since the logic for all 5 is the exact same
    //Receives a CSV file and an array for output
    //Processes the CSV file into the specified array

    parseAnnotation(annotation, pair_array, props) {
        for (let i = 0; i < annotation.length; i++) {
            pair_array.push({
                x: annotation[i],
                y: props.inputArr.data[annotation[i]].y
            });
        }
    }

    static getSelectQuery(annotatorID, ecgID, leadID, pointType) {

        if (annotatorID == 1) {
            var url = new URL("http://128.4.30.6:5000/getFirstAnnotator"),
                params = {ecgID: ecgID, leadID: leadID, pointType: pointType};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

            return url;
        } else {
            var url = new URL("http://128.4.30.6:5000/getSecondAnnotator"),
                params = {ecgID: ecgID, leadID: leadID, pointType: pointType};
            Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));

            return url;
        }
    }

    static parseAnnotations(annotations) {
        //annotations = [ecgID, leadID, annotatorID, pointType]
        const ecgID = annotations[0][0];
        let annotatorID = annotations[0][2];

        var annotationType = annotations[0];
        var leadID = annotationType[1];
        var pointType = annotationType[3];

        var url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p1 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[1];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p2 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[2];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p3 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[3];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p4 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[4];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p5 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[5];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p6 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[6];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p7 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[7];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p8 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        annotationType = annotations[8];
        leadID = annotationType[1];
        pointType = annotationType[3];

        url = this.getSelectQuery(annotatorID, ecgID, leadID, pointType);
        var p9 = fetch(url).then(function (response) {
            return response.json()
        }).then(function (body) {
            return body;
        });

        return Promise.all([p1, p2, p3, p4, p5, p6, p7, p8, p9]).then(arr => {
            return arr
        });

        // var p1 = this.parseAnnotationCsv(annotations[0]).then(data => {
        //     return data
        // })
        // var p2 = this.parseAnnotationCsv(annotations[1]).then(data => {
        //     return data
        // })
        // var p3 = this.parseAnnotationCsv(annotations[2]).then(data => {
        //     return data
        // })
        // var p4 = this.parseAnnotationCsv(annotations[3]).then(data => {
        //     return data
        // })
        // var p5 = this.parseAnnotationCsv(annotations[4]).then(data => {
        //     return data
        // })
        // var p6 = this.parseAnnotationCsv(annotations[5]).then(data => {
        //     return data
        // })
        // var p7 = this.parseAnnotationCsv(annotations[6]).then(data => {
        //     return data
        // })
        // var p8 = this.parseAnnotationCsv(annotations[7]).then(data => {
        //     return data
        // })
        // var p9 = this.parseAnnotationCsv(annotations[8]).then(data => {
        //     return data
        // })
        //
        // return Promise.all([p1, p2, p3, p4, p5, p6, p7, p8, p9]).then(arr => {
        //     return arr
        // });
    }

    //Function to generalize the loading of annotation files
    //Since the logic for all 5 is the exact same
    //Receives a CSV file and an array for output
    //Processes the CSV file into the specified array

    //static selectFromDB(ecgID, leadID)


    static parseAnnotationCsv(inputCsv) {
        var parsed_val = d3.text(inputCsv, function (text) {
            // let data = d3.csv... ; // It was that before but that variable assignment isnt needed
            d3.csv.parseRows(text, function (d) {
                return d.map(Number);
            });
        });

        return parsed_val.then(data => {
            return data.split(',').map(function (item) {
                return parseInt(item, 10);
            })
        });
    }

    // Function to build pairs for graphing
    // Used by ComponentDidUpdate
    addToPairs(anno, freq, pair) {
        for (let i = 0; i < anno.length; i++) {
            pair.push({
                x: anno[i] * (1 / freq),
                y: this.state.data.datasets.data[anno[i]]
            });
        }
        return pair;
    }

    // Runs after render and will re-render
    // If annotations are passed in
    componentDidUpdate(next_props, prev_state) {
        var freq = next_props.inputArr.freq
        //let props_array = next_props.inputArr;

        let dataRead = prev_state.data.datasets.dataRead;
        if (typeof this.state.data.annos !== 'undefined' && this.state.data.annos.length > 4 && this.props !== next_props && this.state.data.annotation !== prev_state.annotation && !dataRead) {
            if (this.state.data.annotation.selectedAnnotation === prev_state.data.annotation.selectedAnnotation) {
                dataRead = true;
                var annos = Graph.parseAnnotations(this.state.data.annos).then(annotations => {
                    return annotations
                });

                // Resolves a promise  made above and returns a new
                // promise, containing the annotation pairs
                let parsed_anno = annos.then(annotations => {
                    let p_pair = [];
                    let q_pair = [];
                    let r_pair = [];
                    let r2_pair = [];
                    let s_pair = [];
                    let t_pair = [];
                    let t2_pair = [];
                    let onset_pair = [];
                    let offset_pair = [];


                    // let p = annotations[0];
                    // let q = annotations[1];
                    // let r = annotations[2];
                    // let r2 = annotations[3];
                    // let s = annotations[4];
                    // let t = annotations[5];
                    // let t2 = annotations[6];
                    // let onset = annotations[7];
                    // let offset = annotations[8];

                    let p = [];
                    annotations[0].forEach(element => { p.push(element.PointIndex);});
                    let q = [];
                    annotations[1].forEach(element => { q.push(element.PointIndex);});
                    let r = [];
                    annotations[2].forEach(element => { r.push(element.PointIndex);});
                    let r2 = [];
                    annotations[3].forEach(element => { r2.push(element.PointIndex);});
                    let s = [];
                    annotations[4].forEach(element => { s.push(element.PointIndex);});
                    let t = [];
                    annotations[5].forEach(element => { t.push(element.PointIndex);});
                    let t2 = [];
                    annotations[6].forEach(element => { t2.push(element.PointIndex);});
                    let onset = [];
                    annotations[7].forEach(element => { onset.push(element.PointIndex);});
                    let offset = [];
                    annotations[8].forEach(element => { offset.push(element.PointIndex);});

                    var p1 = this.addToPairs(p, freq, p_pair);
                    var p2 = this.addToPairs(q, freq, q_pair);
                    var p3 = this.addToPairs(r, freq, r_pair);
                    var p4 = this.addToPairs(r2, freq, r2_pair);
                    var p5 = this.addToPairs(s, freq, s_pair);
                    var p6 = this.addToPairs(t, freq, t_pair);
                    var p7 = this.addToPairs(t2, freq, t2_pair);
                    var p8 = this.addToPairs(onset, freq, onset_pair);
                    var p9 = this.addToPairs(offset, freq, offset_pair);

                    return [p1, p2, p3, p4, p5, p6, p7, p8, p9, this]
                });

                // var newContext = this

                //this.setState({})

                // Resolves the promise made above, and sets the state
                // With the new annotations
                parsed_anno.then(anno => {
                    let p_flag = prev_state.data.annotation.p_flag;
                    let q_flag = prev_state.data.annotation.q_flag;
                    let r_flag = prev_state.data.annotation.r_flag;
                    let r2_flag = prev_state.data.annotation.r2_flag;
                    let s_flag = prev_state.data.annotation.s_flag;
                    let t_flag = prev_state.data.annotation.t_flag;
                    let t2_flag = prev_state.data.annotation.t2_flag;
                    let onset_flag = prev_state.data.annotation.onset_flag;
                    let offset_flag = prev_state.data.annotation.offset_flag;

                    // If the flag was set before, dont change the data
                    if (p_flag)
                        anno[0] = prev_state.data.annotation.p;
                    if (q_flag)
                        anno[1] = prev_state.data.annotation.q;
                    if (r_flag)
                        anno[2] = prev_state.data.annotation.r;
                    if (r2_flag)
                        anno[3] = prev_state.data.annotation.r2;
                    if (s_flag)
                        anno[4] = prev_state.data.annotation.s;
                    if (t_flag)
                        anno[5] = prev_state.data.annotation.t;
                    if (t2_flag)
                        anno[6] = prev_state.data.annotation.t2;
                    if (onset_flag)
                        anno[7] = prev_state.data.annotation.onset;
                    if (offset_flag)
                        anno[8] = prev_state.data.annotation.offset;

                    // Set flag to true if the data has been loaded
                    if (!p_flag && anno[0] > 0)
                        p_flag = true;

                    if (!q_flag && anno[1] > 0)
                        q_flag = true;

                    if (!r_flag && anno[2] > 0)
                        r_flag = true;

                    if (!r2_flag && anno[3] > 0)
                        r_flag = true;

                    if (!s_flag && anno[4] > 0)
                        s_flag = true;

                    if (!t_flag && anno[5] > 0)
                        t_flag = true;

                    if (!t2_flag && anno[6] > 0)
                        t_flag = true;

                    if (!onset_flag && anno[7] > 0)
                        onset_flag = true;

                    if (!offset_flag && anno[8] > 0)
                        offset_flag = true;

                    this.setState({
                        data: {
                            dataRead: dataRead,
                            annotation: {
                                p: anno[0],
                                q: anno[1],
                                r: anno[2],
                                r2: anno[3],
                                s: anno[4],
                                t: anno[5],
                                t2: anno[6],
                                onset: anno[7],
                                offset: anno[8],
                                selectedAnnotation: prev_state.data.annotation.selectedAnnotation,
                                p_flag: p_flag,
                                q_flag: q_flag,
                                r_flag: r_flag,
                                r2_flag: r2_flag,
                                s_flag: s_flag,
                                t_flag: t_flag,
                                t2_flag: t2_flag,
                                onset_flag: onset_flag,
                                offset_flag: offset_flag

                            },
                            annotatorID: this.props.inputArr.annotatorID
                            //annotatorID:
                        }
                    })
                })
            } else {
                this.setState({
                    data: {
                        dataRead: dataRead,
                        annotation: {
                            p: prev_state.data.annotation.p,
                            q: prev_state.data.annotation.q,
                            r: prev_state.data.annotation.r,
                            r2: prev_state.data.annotation.r2,
                            s: prev_state.data.annotation.s,
                            t: prev_state.data.annotation.t,
                            t2: prev_state.data.annotation.t2,
                            onset: prev_state.data.annotation.onset,
                            offset: prev_state.data.annotation.offset,
                            selectedAnnotation: next_props.inputArr.extra_info.selectedAnnotation
                        }
                    }
                })
            }
        }
    }

    /**
     *
     * @brief React method that handles setting state when new props are passed from the parent container.
     * Here we are using this method to take annotation data passed in a props and format it correctly
     * for display as a Scatter plot in Chartjs. Sets new state for the graph after processing the props
     *
     * @param {props} next_props
     * @param {props} prev_state
     */
    static getDerivedStateFromProps(next_props, prev_state) {

        var freq = next_props.inputArr.freq

        //let props_array = next_props.inputArr;

        //console.log('prev_state',prev_state)

        if (undefined !== next_props.inputArr.annotations_all && next_props.inputArr.annotations_all.length > 4) {
            return {
                data: {
                    datasets: {
                        radius: 0, // Makes the dots go away
                        label: next_props.inputArr.title,
                        fill: false,
                        borderColor: ['black'],
                        data: next_props.inputArr.data,
                        backgroundColor: ['rgba(255,99,132,0.6)',],
                        borderWidth: 1
                    },
                    annotation: {
                        p: prev_state.data.annotation.p,
                        q: prev_state.data.annotation.q,
                        r: prev_state.data.annotation.r,
                        r2: prev_state.data.annotation.r2,
                        s: prev_state.data.annotation.s,
                        t: prev_state.data.annotation.t,
                        t2: prev_state.data.annotation.t2,
                        onset: prev_state.data.annotation.onset,
                        offset: prev_state.data.annotation.offset,
                        selectedAnnotation: next_props.inputArr.extra_info.selectedAnnotation,
                        oldP: [''],
                        oldQ: [''],
                        oldR: [''],
                        oldR2: [''],
                        oldS: [''],
                        oldT: [''],
                        oldT2: [''],
                        oldOnset: [''],
                        oldOffset: [''],
                        p_flag: prev_state.data.annotation.p_flag,
                        q_flag: prev_state.data.annotation.q_flag,
                        r_flag: prev_state.data.annotation.r_flag,
                        r2_flag: prev_state.data.annotation.r2_flag,
                        s_flag: prev_state.data.annotation.s_flag,
                        t_flag: prev_state.data.annotation.t_flag,
                        t2_flag: prev_state.data.annotation.t2_flag,
                        onset_flag: prev_state.data.annotation.onset_flag,
                        offset_flag: prev_state.data.annotation.offset_flag
                    },
                    scanID: next_props.inputArr.scanID,
                    freq: freq,
                    min: next_props.inputArr.extra_info.min,
                    max: next_props.inputArr.extra_info.max,
                    parent_width: next_props.width,
                    annos: next_props.inputArr.annotations_all
                }
            }
        } else {
            return {
                data: {
                    datasets: {
                        radius: 0, // Makes the dots go away
                        label: next_props.inputArr.title,
                        fill: false,
                        borderColor: ['black'],
                        data: next_props.inputArr.data,
                        backgroundColor: ['rgba(255,99,132,0.6)',],
                        borderWidth: 1
                    },
                    annotation: {
                        p: [{x: 0, y: 10000}], // y's need an initial point, which is outside of range of graph
                        q: [{x: 0, y: 10000}], // however, they are removed on the first update
                        r: [{x: 0, y: 10000}],
                        r2: [{x: 0, y: 10000}],
                        s: [{x: 0, y: 10000}],
                        t: [{x: 0, y: 10000}],
                        t2: [{x: 0, y: 10000}],
                        onset: [{x: 0, y: 10000}],
                        offset: [{x: 0, y: 10000}],
                        selectedAnnotation: next_props.inputArr.extra_info.selectedAnnotation,
                        oldP: [''],
                        oldQ: [''],
                        oldR: [''],
                        oldR2: [''],
                        oldS: [''],
                        oldT: [''],
                        oldT2: [''],
                        oldOnset: [''],
                        oldOffset: [''],
                        p_flag: false,
                        q_flag: false,
                        r_flag: false,
                        r2_flag: false,
                        s_flag: false,
                        t_flag: false,
                        t2_flag: false,
                        onset_flag: false,
                        offset_flag: false,
                    },
                    scanID: next_props.inputArr.scanID,
                    freq: freq,
                    min: next_props.inputArr.extra_info.min,
                    max: next_props.inputArr.extra_info.max,
                    parent_width: next_props.width,
                    annos: prev_state.annos
                }
            }
        }
    }


    //Render the graph
    render() {
        const dat = {
            type: 'Scatter',
            datasets: [
                {
                    label: 'Main-Data',
                    fill: false,
                    backgroundColor: 'rgba(75,192,192,0.4)',
                    pointBorderColor: 'rgba(75,192,192,1)',
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 1,
                    pointHoverRadius: 1,
                    pointHoverBackgroundColor: 'rgba(75,192,192,1)',
                    pointHoverBorderColor: 'rgba(220,220,220,1)',
                    pointHoverBorderWidth: 1,
                    pointRadius: 0, // This makes the individual points disappear
                    pointHitRadius: 2,
                    borderWidth: 1.5, // Change this back to 1???
                    borderColor: 'black',
                    showLine: true,
                    tooltipHidden: true,
                    data: this.state.data.datasets.data,
                },
                {
                    label: 'P',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorP,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorPOpacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.p
                },
                {
                    label: 'Q',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorQ,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorQOpacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.q
                },
                {
                    label: 'R',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorR,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorROpacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.r
                },
                {
                    label: 'R2',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorR2,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorR2Opacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.r2
                },
                {
                    label: 'S',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorS,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorSOpacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.s
                },
                {
                    label: 'T',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorT,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorTOpacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.t
                },
                {
                    label: 'T2',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorT2,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorT2Opacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.t2
                },
                {
                    label: 'Onset',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorOn,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorOnOpacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.onset
                },
                {
                    label: 'Offset',
                    fill: true,
                    pointStyle: 'circle',
                    pointBorderColor: colorOff,
                    pointRadius: 5,
                    pointHitRadius: 3,
                    pointHoverRadius: 10,
                    pointBorderWidth: 2,
                    backgroundColor: colorOffOpacity,
                    showLine: false,
                    tooltipHidden: false,
                    data: this.state.data.annotation.offset
                },
            ],
        };

        let dataLen = this.state.data.datasets.data.length
        let total_time = 1
        if (this.state.data.datasets.data[dataLen - 1]) {
            total_time = this.state.data.datasets.data[dataLen - 1].x
            total_time += 1 / this.state.data.freq
        }

        // Some constants
        const HEIGHT = 225; // The stated height of the chart
        //const INTERVAL = 0.2 // 0.2 seconds or 200 ms
        const SECONDS_PER_WIDTH_MAX = 10
        const TIME_PER_WIDTH = Math.min(SECONDS_PER_WIDTH_MAX, total_time) // Number of seconds to fit on the screen at a time

        // The amount of the width/height that is not part of the graph
        const width_offset = 86 //     (75 + 10 + 1 + 1) = offset = 86

        // The fixed width of the container on the screen
        const parent_width = this.state.data.parent_width - width_offset

        // The amount of px that will be visible in every given second of the x axis
        const px_per_second = parent_width / TIME_PER_WIDTH;

        // Calculates the width of the graph(can be greater than the fixed width, scrollable allow the excess to be seen)
        let width = total_time * px_per_second;
        width += width_offset
        width += 'px'

        /** Legends within each graph
         * <div style={{position: 'absolute', top:0, right:0}}>
         <ul style = {{ position: 'relative', fontSize: '9px', fontWeight: 'bold' , marginLeft: -10}}>
         <div><span className={styles.p} ></span>P</div>
         <div><span className={styles.q}></span>Q</div>
         <div><span className={styles.r}></span>R</div>
         <div><span className={styles.s}></span>S</div>
         <div><span className={styles.t}></span>T</div>
         </ul>
         </div>
         */

        return (
            <React.Fragment>
                {

                    <div className="wrapper" style={{position: 'relative', height: HEIGHT}}>

                        <div style={{
                            position: 'absolute',
                            fontSize: 20,
                            marginTop: 0,
                            fontWeight: 'bold'
                        }}>{this.state.data.datasets.label}</div>


                        <div className="graph" style={{position: 'absolute', top: 0, left: 0, width: width}}>
                            <Scatter
                                data={dat}
                                redraw={true}
                                height={HEIGHT}
                                ref={this.chartRef}
                                getElementAtEvent={(point) => {
                                    //let selected_anno = this.state.data.annotation.selectedAnnotation
                                    // if (point.length > 0 && selected_anno && selected_anno !== -1) {
                                    //     this.modifyGraph(point);
                                    // }
                                    if (point.length == 0) {

                                    } else {
                                        this.modifyGraph(point);
                                    }
                                }}
                                options={{
                                    maintainAspectRatio: false,
                                    tooltips: {
                                        enabled: true,
                                        mode: 'nearest',
                                        /*custom: function(tooltipModel) {
                                            // EXTENSION: filter is not enough! Hide tooltip frame
                                            if (!tooltipModel.body || tooltipModel.body.length < 1) {
                                                tooltipModel.caretSize = 0;
                                                tooltipModel.xPadding = 0;
                                                tooltipModel.yPadding = 0;
                                                tooltipModel.cornerRadius = 0;
                                                tooltipModel.width = 0;
                                                tooltipModel.height = 0;
                                            }
                                        },
                                        filter: function(tooltipItem, data) {
                                            return !data.datasets[tooltipItem.datasetIndex].tooltipHidden;
                                        },*/
                                        callbacks: {
                                            label: function (tooltipItems, data) {
                                                return tooltipItems.xLabel + ' s, ' + tooltipItems.yLabel + ' mv';
                                            }.bind(this)
                                        }
                                    },
                                    title: {
                                        display: false,
                                        text: this.state.data.datasets.label,
                                        fontSize: 13,
                                        fontFamily: "serif",
                                        position: 'left'
                                    },
                                    legend: {
                                        display: false,
                                        position: 'right',
                                        labels: {
                                            // generateLabel
                                            boxWidth: 10,
                                            filter: function (item) {
                                                // Remove the legend of the main-data, keep the annotation legend
                                                return !item.text.includes('Main-Data');
                                            }.bind(this)
                                        }
                                    },
                                    scales: {
                                        xAxes: [{
                                            ticks: {
                                                display: false,
                                                stepSize: 0.2
                                            },
                                            gridLines: {
                                                display: false
                                            },
                                            scaleLabel: {
                                                display: false,
                                                labelString: 'Seconds'
                                            }
                                        }],
                                        yAxes: [{
                                            ticks: {
                                                display: false,
                                                min: this.state.data.min,
                                                max: this.state.data.max + 50
                                            },
                                            gridLines: {
                                                display: false
                                            },
                                            scaleLabel: {
                                                display: false,
                                                labelString: 'MV'
                                            }
                                        }]
                                    }
                                }}
                            />
                        </div>
                    </div>
                }
            </React.Fragment>)
    }

}

export default Graph; 
