import React from "react";

import styles from "./LoadData.module.scss";
import Select from 'react-select';
import * as d3 from "d3";
//import MainContainer from "../MainContainer/MainContainer";
//import files from '../../csv_files'
//import * as Items from '../../csv_files';
//import listReactFiles from 'list-react-files'
var file_list = [];
//var file_names = [];
const options = [];



/**
 * This component defines the search bar that enables dynamic loading of CSV files
 * CSV files must be added to the 'csv_files' folder located at '../../csv_files'
 * 
 * Changing the first argument of the file_list and file_string variables below will 
 * change where the component searches for CSV files.
 */
export default class LoadData extends React.Component {
    
    // Loads first CSV and imports the list of CSVs
    constructor(props) {
        super(props);

        this.annotation = [];
    
        file_list = this.importAll(require.context('../../csv_files', false,  /\.csv$/));
        var file_string = this.importAllNames(require.context('../../csv_files', false,  /\.csv$/));

        //const {callBack} = this.props
        
        for(var i = 0; i < file_list.length; i++){
            options.push({ label: file_string[i], value: file_list[i]});
        }
        
    }
    
    // Imports list of CSV files
    importAll(r) {
        return r.keys().map(r);
    }
    
    // Imports list of CSV file names (readable), to be used for selection
    importAllNames(r){
        return r.keys();
    }



    
    importAnnotations(csv_name){
        // Following line gets new CSV name without ./ and .csv (returned by importAll)
        let csv_spliced = csv_name.slice(2, csv_name.length - 4)

        // Set Leads (Index 0: P, Index 1: Q, R, S, T)
        let lead_i = [];
        let lead_ii = [];
        let lead_iii = [];
        let lead_avr = [];
        let lead_avl = [];
        let lead_avf = [];
        let lead_v1 = [];
        let lead_v2 = [];
        let lead_v3 = [];
        let lead_v4 = [];
        let lead_v5 = [];
        let lead_v6 = [];

        // let annotatorID = 1;
        //
        //
        // if (annotatorID == 1) {
        //
        //     const url = new URL("http://localhost:5000/getFirstAnnotator"),
        //         params = {ecgID: 1};
        //     Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
        //
        //     fetch(url)
        //         .then(function(response){
        //             return response.json()
        //         }).then(function(body){
        //
        //         body.forEach(item => {
        //
        //             console.log(item);
        //
        //         });
        //
        //     });
        //
        // } else {
        //
        //     const url = new URL("http://localhost:5000/getSecondAnnotator"),
        //         params = {ecgID: 1};
        //     Object.keys(params).forEach(key => url.searchParams.append(key, params[key]));
        //
        //     fetch(url)
        //         .then(function (response) {
        //             return response.json()
        //         }).then(function (body) {
        //
        //     });
        // }
        //
        //
        // var b = 9;


        //var directoryContents = readdir.readSync('../../annotations');

        // Get full list of annotations
        // The true means it looks in subdirectories as well, which is how we can put the folders inside each other
        //        You could break the folders down even more and it should still work
        let annotations = this.importAll(require.context('../../annotations', true,  /\.csv$/));

        let correct_a = [];

        // Correct_a saves annotations for the correct graph
        annotations.forEach(element => {
            if(element.includes(csv_spliced, 0)){
                correct_a.push(element)

            }
        });

        correct_a.forEach(element => {
            if(element.includes("III", 0)){
                lead_iii.push(element)
            } else if(element.includes("aVL", 0)){
                lead_avl.push(element)
            } else if(element.includes("II", 0)){
                lead_ii.push(element)
            } else if(element.includes("I", 0)){
                lead_i.push(element)
            } else if(element.includes("aVF", 0)){
                lead_avf.push(element)
            } else if(element.includes("aVR", 0)){
                lead_avr.push(element)
            } else if(element.includes("V1", 0)){
                lead_v1.push(element)
            } else if(element.includes("V2", 0)){
                lead_v2.push(element)
            } else if(element.includes("V3", 0)){
                lead_v3.push(element)
            } else if(element.includes("V4", 0)){
                lead_v4.push(element)
            } else if(element.includes("V5", 0)){
                lead_v5.push(element)
            } else if(element.includes("V6", 0)){
                lead_v6.push(element)
            }
        })

        // Sorts them in alphabetical order, so they match (P,Q,R,S,T indices)
        lead_i.sort();
        var temp = lead_i[0];
        var temp2 = lead_i[1];
        lead_i.shift();
        lead_i.shift();
        lead_i.push(temp2);
        lead_i.push(temp);

        lead_ii.sort()
        temp = lead_ii[0];
        temp2 = lead_ii[1];
        lead_ii.shift();
        lead_ii.shift();
        lead_ii.push(temp2);
        lead_ii.push(temp);

        lead_iii.sort()
        temp = lead_iii[0];
        temp2 = lead_iii[1];
        lead_iii.shift();
        lead_iii.shift();
        lead_iii.push(temp2);
        lead_iii.push(temp);

        lead_avl.sort()
        temp = lead_avl[0];
        temp2 = lead_avl[1];
        lead_avl.shift();
        lead_avl.shift();
        lead_avl.push(temp2);
        lead_avl.push(temp);

        lead_avf.sort()
        temp = lead_avf[0];
        temp2 = lead_avf[1];
        lead_avf.shift();
        lead_avf.shift();
        lead_avf.push(temp2);
        lead_avf.push(temp);

        lead_avr.sort()
        temp = lead_avr[0];
        temp2 = lead_avr[1];
        lead_avr.shift();
        lead_avr.shift();
        lead_avr.push(temp2);
        lead_avr.push(temp);

        lead_v1.sort()
        temp = lead_v1[0];
        temp2 = lead_v1[1];
        lead_v1.shift();
        lead_v1.shift();
        lead_v1.push(temp2);
        lead_v1.push(temp);

        lead_v2.sort()
        temp = lead_v2[0];
        temp2 = lead_v2[1];
        lead_v2.shift();
        lead_v2.shift();
        lead_v2.push(temp2);
        lead_v2.push(temp);

        lead_v3.sort()
        temp = lead_v3[0];
        temp2 = lead_v3[1];
        lead_v3.shift();
        lead_v3.shift();
        lead_v3.push(temp2);
        lead_v3.push(temp);

        lead_v4.sort()
        temp = lead_v4[0];
        temp2 = lead_v4[1];
        lead_v4.shift();
        lead_v4.shift();
        lead_v4.push(temp2);
        lead_v4.push(temp);

        lead_v5.sort()
        temp = lead_v5[0];
        temp2 = lead_v5[1];
        lead_v5.shift();
        lead_v5.shift();
        lead_v5.push(temp2);
        lead_v5.push(temp);

        lead_v6.sort()
        temp = lead_v6[0];
        temp2 = lead_v6[1];
        lead_v6.shift();
        lead_v6.shift();
        lead_v6.push(temp2);
        lead_v6.push(temp);

        //let all_annotations = [lead_i, lead_avl, lead_ii, lead_iii, lead_avf, lead_avr, lead_v1, lead_v2, lead_v3, lead_v4, lead_v5, lead_v6];

        let all_annotations = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120];

        return all_annotations
    }
    
    
    // Sets state for options, and handles which CSV is loaded upon selection
    state = {
    selectedOption: null,
    };
    handleChange = selectedOption => {
        this.setState(
                      { selectedOption },
                      () => this.props.callBack(this.state.selectedOption.value, this.importAnnotations(this.state.selectedOption.label), this.state.selectedOption.label)
                      );
    };
    
    // Renders the selectable list at the top
    render () {
        const { selectedOption } = this.state;
        //const { file_names } = this.state;
        
        return (
                <div className={styles.LoadData}>
                <Select
                    value={selectedOption}
                    onChange={this.handleChange}
                    options={options}
                />
                </div>
                );
    }
}